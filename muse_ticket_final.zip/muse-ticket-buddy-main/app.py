import os
import re
from flask import Flask, render_template, request, jsonify, redirect, url_for, session
from langchain.memory import ConversationBufferMemory
from langchain.prompts import PromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.runnables import RunnableSequence
from pymongo import MongoClient
from dotenv import load_dotenv
import dateparser

# === Load env ===
load_dotenv()
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")

# === Flask app ===
app = Flask(__name__, template_folder="templates", static_folder="public")
app.secret_key = "your_secret_key"  # Replace with secure secret

# === MongoDB ===
mongo_client = MongoClient(MONGO_URI)
db = mongo_client["museum_booking_db"]
users = db["users"]
bookings = db["ticket_bookings"]

# === LangChain LLM ===
llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash-latest")
memory = ConversationBufferMemory(memory_key="chat_history", input_key="user_input")

# === Chatbot prompt ===
prompt = PromptTemplate(
    input_variables=["chat_history", "user_input"],
    template="""
You are a smart multilingual Museum Ticket Booking Assistant.
Your job is to collect:
- museum_name
- ticket_type (Gate Entry or Show)
- number of tickets
- date of visit (can be today, tomorrow, or specific date)
- email address

Keep the conversation casual but clear.
Once you have all 5, confirm back in this format:

museum_name: <value>
ticket_name: <value>
number: <value>
date: <value>
email: <value>

and say "✅ All details collected. Saving to database now."
Conversation so far:
{chat_history}

User: {user_input}
Assistant:
"""
)

chain = RunnableSequence(
    prompt | llm | (lambda output: {"text": output.content})
)

def parse_date(natural_date):
    parsed = dateparser.parse(natural_date)
    if parsed:
        return parsed.strftime("%Y-%m-%d")
    return natural_date

# === Routes ===

@app.route("/")
def home():
    if "user" in session:
        return render_template("index.html", user=session["user"])
    else:
        return redirect(url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        print("--- DEBUG: Inside /login POST request ---")
        print(f"--- DEBUG: request.form content: {request.form} ---")
        
        # Use .get() to avoid KeyError if 'email' is truly missing
        email = request.form.get("email") 
        password = request.form.get("password")

        if not email or not password:
            print("--- DEBUG: Email or password missing from form data ---")
            return render_template("login.html", error="Email and password are required.")

        user = users.find_one({"email": email, "password": password})
        if user:
            session["user"] = email
            print(f"--- DEBUG: User {email} logged in successfully ---")
            return redirect(url_for("home"))
        else:
            print(f"--- DEBUG: Invalid credentials for {email} ---")
            return render_template("login.html", error="Invalid credentials.")
    return render_template("login.html")

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        print("--- DEBUG: Inside /signup POST request ---")
        print(f"--- DEBUG: request.form content: {request.form} ---")

        # Use .get() to avoid KeyError if 'email' is truly missing
        email = request.form.get("email")
        password = request.form.get("password")

        if not email or not password:
            print("--- DEBUG: Email or password missing from form data ---")
            return render_template("signup.html", error="Email and password are required.")

        if users.find_one({"email": email}):
            print(f"--- DEBUG: Email {email} already exists ---")
            return render_template("signup.html", error="Email already exists!")

        users.insert_one({"email": email, "password": password})
        print(f"--- DEBUG: User {email} signed up successfully ---")
        return render_template("signup.html", success="Account created! Please log in.")
    return render_template("signup.html")

@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("login"))

@app.route("/chatbot")
def chatbot():
    if "user" not in session:
        return redirect(url_for("login"))
    return render_template("chatbot.html")

@app.route("/chat", methods=["POST"])
def chat():
    if "user" not in session:
        return jsonify({"reply": "Please log in first."}), 401

    user_input = request.json["message"]
    memory.chat_memory.add_user_message(user_input)

    response = chain.invoke({
        "chat_history": memory.buffer,
        "user_input": user_input
    })

    bot_reply = response["text"].strip()
    memory.chat_memory.add_ai_message(bot_reply)

    if "✅ All details collected" in bot_reply:
        def extract(slot):
            match = re.search(rf"{slot}[:=]\s*(.+)", bot_reply, re.IGNORECASE)
            return match.group(1).strip() if match else "UNKNOWN"

        museum_name = extract("museum_name")
        ticket_type = extract("ticket_type")
        number = extract("number")
        date = parse_date(extract("date"))
        email = extract("email")

        booking = {
            "museum_name": museum_name,
            "ticket_type": ticket_type,
            "number": number,
            "date": date,
            "email": email,
            "payment_status": "Pending",
            "created_by": session["user"]
        }

        bookings.insert_one(booking)
        bot_reply += f"\n✅ Booking saved:\n{booking}"

    return jsonify({"reply": bot_reply})

if __name__ == "__main__":
    app.run(debug=True)
