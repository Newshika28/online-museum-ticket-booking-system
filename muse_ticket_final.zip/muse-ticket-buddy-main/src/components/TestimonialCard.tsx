
import { Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface TestimonialCardProps {
  name: string;
  avatar: string;
  rating: number;
  text: string;
  delay?: number;
}

export const TestimonialCard = ({ name, avatar, rating, text, delay = 0 }: TestimonialCardProps) => {
  return (
    <Card 
      className="hover-scale border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-gradient-to-br from-background to-muted/10 animate-fade-in"
      style={{ animationDelay: `${delay}s` }}
    >
      <CardContent className="p-6">
        <div className="flex mb-4">
          {Array.from({ length: rating }).map((_, i) => (
            <Star key={i} className="h-4 w-4 text-yellow-500 fill-current" />
          ))}
        </div>
        
        <blockquote className="text-lg italic text-foreground mb-4 leading-relaxed">
          "{text}"
        </blockquote>
        
        <div className="flex items-center space-x-3">
          <img 
            src={avatar} 
            alt={name}
            className="h-12 w-12 rounded-full object-cover border-2 border-primary/20"
          />
          <div>
            <div className="font-semibold">{name}</div>
            <div className="text-sm text-muted-foreground">Verified Customer</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
