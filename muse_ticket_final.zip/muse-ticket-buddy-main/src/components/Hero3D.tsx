
import { useRef, useEffect } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Text, Float, Sphere, Box, Torus } from "@react-three/drei";
import * as THREE from "three";

const MuseumScene = () => {
  const groupRef = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.1;
    }
  });

  return (
    <group ref={groupRef}>
      {/* Main Museum Building */}
      <Float speed={1} rotationIntensity={0.2} floatIntensity={0.5}>
        <Box args={[2, 1.5, 1]} position={[0, 0, 0]}>
          <meshStandardMaterial color="#8B5CF6" />
        </Box>
      </Float>

      {/* Columns */}
      <Float speed={1.2} rotationIntensity={0.1} floatIntensity={0.3}>
        <Box args={[0.2, 2, 0.2]} position={[-0.6, 0.2, 0.6]}>
          <meshStandardMaterial color="#A78BFA" />
        </Box>
        <Box args={[0.2, 2, 0.2]} position={[0.6, 0.2, 0.6]}>
          <meshStandardMaterial color="#A78BFA" />
        </Box>
      </Float>

      {/* Floating Art Pieces */}
      <Float speed={2} rotationIntensity={0.4} floatIntensity={1}>
        <Sphere args={[0.3]} position={[-2, 1, 0]}>
          <meshStandardMaterial color="#F59E0B" emissive="#F59E0B" emissiveIntensity={0.2} />
        </Sphere>
      </Float>

      <Float speed={1.5} rotationIntensity={0.3} floatIntensity={0.8}>
        <Torus args={[0.4, 0.1, 8, 24]} position={[2, 0.5, 0]} rotation={[Math.PI / 4, 0, 0]}>
          <meshStandardMaterial color="#EF4444" emissive="#EF4444" emissiveIntensity={0.1} />
        </Torus>
      </Float>

      <Float speed={1.8} rotationIntensity={0.5} floatIntensity={1.2}>
        <Box args={[0.4, 0.4, 0.1]} position={[1, 2, -1]} rotation={[0, Math.PI / 4, 0]}>
          <meshStandardMaterial color="#10B981" emissive="#10B981" emissiveIntensity={0.15} />
        </Box>
      </Float>

      {/* Floating Text */}
      <Float speed={1} rotationIntensity={0.1} floatIntensity={0.4}>
        <Text
          position={[0, -2, 0]}
          fontSize={0.5}
          color="#8B5CF6"
          anchorX="center"
          anchorY="middle"
          font="/fonts/Inter-Bold.woff"
        >
          MuseTicket
        </Text>
      </Float>

      {/* Particle-like spheres */}
      {Array.from({ length: 8 }).map((_, i) => (
        <Float
          key={i}
          speed={0.5 + Math.random()}
          rotationIntensity={0.2}
          floatIntensity={0.5 + Math.random() * 0.5}
        >
          <Sphere
            args={[0.05]}
            position={[
              (Math.random() - 0.5) * 6,
              (Math.random() - 0.5) * 4,
              (Math.random() - 0.5) * 4,
            ]}
          >
            <meshStandardMaterial 
              color={`hsl(${Math.random() * 360}, 70%, 60%)`} 
              emissive={`hsl(${Math.random() * 360}, 70%, 30%)`}
              emissiveIntensity={0.3}
            />
          </Sphere>
        </Float>
      ))}
    </group>
  );
};

const Lights = () => {
  return (
    <>
      <ambientLight intensity={0.4} />
      <pointLight position={[10, 10, 10]} intensity={1} />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#8B5CF6" />
      <spotLight
        position={[0, 15, 0]}
        angle={0.3}
        penumbra={1}
        intensity={1}
        castShadow
        color="#A78BFA"
      />
    </>
  );
};

export const Hero3D = () => {
  return (
    <div className="w-full h-96 relative">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10 rounded-2xl"></div>
      <Canvas
        camera={{ position: [0, 0, 8], fov: 60 }}
        className="rounded-2xl"
        gl={{ alpha: true, antialias: true }}
      >
        <Lights />
        <MuseumScene />
        <OrbitControls
          enableZoom={false}
          enablePan={false}
          autoRotate
          autoRotateSpeed={1}
          maxPolarAngle={Math.PI / 2}
          minPolarAngle={Math.PI / 4}
        />
      </Canvas>
      
      {/* Glow overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-background/20 via-transparent to-background/20 rounded-2xl pointer-events-none"></div>
    </div>
  );
};
