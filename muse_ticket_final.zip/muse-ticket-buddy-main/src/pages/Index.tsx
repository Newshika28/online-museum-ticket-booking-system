
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Calendar, Clock, MapPin, Star, Users, Sparkles, Building, Ticket, Globe } from "lucide-react";
import { ChatWidget } from "@/components/ChatWidget";
import { Hero3D } from "@/components/Hero3D";
import { FeatureCard } from "@/components/FeatureCard";
import { TestimonialCard } from "@/components/TestimonialCard";
import { StatsCounter } from "@/components/StatsCounter";

const Index = () => {
  const [isChatOpen, setIsChatOpen] = useState(false);

  const featuredMuseums = [
    {
      id: 1,
      name: "Indian Museum",
      location: "Kolkata, India",
      image: "https://images.unsplash.com/photo-1466442929976-97f336a657be",
      rating: 4.7,
      visitors: "1.2M",
      description: "India's oldest and largest museum with rare collections of antiques",
      price: "₹20",
      category: "History & Culture"
    },
    {
      id: 2,
      name: "National Museum",
      location: "New Delhi, India",
      image: "https://images.unsplash.com/photo-1494891848038-7bd202a2afeb",
      rating: 4.6,
      visitors: "800K",
      description: "Premier museum showcasing India's rich cultural heritage",
      price: "₹20",
      category: "Art & History"
    },
    {
      id: 3,
      name: "Chhatrapati Shivaji Maharaj Museum",
      location: "Mumbai, India",
      image: "https://images.unsplash.com/photo-1460574283810-2aab119d8511",
      rating: 4.5,
      visitors: "600K",
      description: "Formerly Prince of Wales Museum, showcasing Indian art and culture",
      price: "₹15",
      category: "Art & Culture"
    }
  ];

  const features = [
    {
      icon: Ticket,
      title: "Smart Booking",
      description: "AI-powered assistant helps you book Indian museum tickets instantly"
    },
    {
      icon: Calendar,
      title: "Flexible Dates",
      description: "Choose any date with real-time availability across India"
    },
    {
      icon: Globe,
      title: "Indian Museums",
      description: "Access to museums across India in multiple regional languages"
    },
    {
      icon: Sparkles,
      title: "Heritage Experience",
      description: "Skip lines and enjoy exclusive Indian cultural experiences"
    }
  ];

  const testimonials = [
    {
      name: "Priya Sharma",
      avatar: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158",
      rating: 5,
      text: "Amazing service! Booked tickets for Indian Museum in Kolkata seamlessly. The AI assistant understood my needs perfectly!"
    },
    {
      name: "Rajesh Kumar",
      avatar: "https://images.unsplash.com/photo-1649972904349-6e44c42644a7",
      rating: 5,
      text: "Love how easy it is to explore India's cultural heritage. The museum recommendations were excellent!"
    }
  ];

  const stats = [
    { number: 150, label: "Indian Museums", suffix: "+" },
    { number: 500000, label: "Heritage Visitors", suffix: "" },
    { number: 28, label: "States Covered", suffix: "+" },
    { number: 4.7, label: "Average Rating", suffix: "★" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-background/80 backdrop-blur-lg border-b border-border/50 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Building className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Indian Museum Hub
            </span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <a href="#home" className="text-foreground hover:text-primary transition-colors">Home</a>
            <a href="#museums" className="text-foreground hover:text-primary transition-colors">Museums</a>
            <a href="#features" className="text-foreground hover:text-primary transition-colors">Features</a>
            <a href="#about" className="text-foreground hover:text-primary transition-colors">About</a>
          </div>

          <Button 
            onClick={() => setIsChatOpen(true)}
            className="bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-lg hover:shadow-xl transition-all duration-300"
          >
            Book Now <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="pt-20 pb-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5"></div>
        
        <div className="container mx-auto px-4 grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-fade-in">
            <Badge className="w-fit bg-primary/10 text-primary border-primary/20">
              <Sparkles className="w-4 h-4 mr-2" />
              AI-Powered Indian Museum Booking
            </Badge>
            
            <h1 className="text-5xl lg:text-7xl font-bold leading-tight">
              Discover India's
              <span className="block bg-gradient-to-r from-primary via-primary/80 to-accent bg-clip-text text-transparent">
                Cultural
              </span>
              Heritage
            </h1>
            
            <p className="text-xl text-muted-foreground leading-relaxed max-w-lg">
              Book tickets to India's most incredible museums and heritage sites with our AI assistant. 
              Skip the lines, plan your cultural journey, and explore India's rich history.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg"
                onClick={() => setIsChatOpen(true)}
                className="bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-lg hover:shadow-xl transition-all duration-300 text-lg px-8 py-6"
              >
                Start Booking <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              
              <Button 
                size="lg" 
                variant="outline"
                className="border-2 hover:bg-primary/5 text-lg px-8 py-6"
              >
                Explore Heritage
              </Button>
            </div>

            <div className="flex items-center space-x-6 pt-4">
              {stats.slice(0, 2).map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-2xl font-bold text-primary">
                    <StatsCounter target={stat.number} suffix={stat.suffix} />
                  </div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative lg:h-96">
            <Hero3D />
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gradient-to-r from-primary/5 to-accent/5">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                <div className="text-4xl md:text-5xl font-bold text-primary mb-2">
                  <StatsCounter target={stat.number} suffix={stat.suffix} />
                </div>
                <div className="text-muted-foreground font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 space-y-4">
            <Badge className="bg-primary/10 text-primary border-primary/20">Features</Badge>
            <h2 className="text-4xl md:text-5xl font-bold">Why Choose Indian Museum Hub?</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Experience the future of Indian heritage exploration with our cutting-edge platform
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <FeatureCard key={index} {...feature} delay={index * 0.1} />
            ))}
          </div>
        </div>
      </section>

      {/* Featured Museums */}
      <section id="museums" className="py-20 bg-gradient-to-b from-muted/20 to-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 space-y-4">
            <Badge className="bg-primary/10 text-primary border-primary/20">Heritage Destinations</Badge>
            <h2 className="text-4xl md:text-5xl font-bold">Featured Indian Museums</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Discover India's most prestigious museums and cultural institutions
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredMuseums.map((museum, index) => (
              <Card key={museum.id} className="group hover-scale overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-300 animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                <div className="relative overflow-hidden">
                  <img 
                    src={museum.image} 
                    alt={museum.name}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4">
                    <Badge className="bg-background/90 text-foreground">{museum.category}</Badge>
                  </div>
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-primary text-primary-foreground">{museum.price}</Badge>
                  </div>
                </div>
                
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl group-hover:text-primary transition-colors">
                        {museum.name}
                      </CardTitle>
                      <CardDescription className="flex items-center mt-2">
                        <MapPin className="w-4 h-4 mr-1" />
                        {museum.location}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <p className="text-muted-foreground mb-4">{museum.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-yellow-500 fill-current" />
                        <span className="ml-1 font-medium">{museum.rating}</span>
                      </div>
                      <div className="flex items-center text-muted-foreground">
                        <Users className="w-4 h-4 mr-1" />
                        <span className="text-sm">{museum.visitors}</span>
                      </div>
                    </div>
                    
                    <Button 
                      onClick={() => setIsChatOpen(true)}
                      size="sm"
                      className="bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70"
                    >
                      Book Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 space-y-4">
            <Badge className="bg-primary/10 text-primary border-primary/20">Testimonials</Badge>
            <h2 className="text-4xl md:text-5xl font-bold">What Our Heritage Lovers Say</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {testimonials.map((testimonial, index) => (
              <TestimonialCard key={index} {...testimonial} delay={index * 0.2} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary via-primary/90 to-accent text-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        
        <div className="container mx-auto px-4 text-center relative z-10">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Ready to Explore India's Heritage?
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Join thousands of heritage enthusiasts who trust Indian Museum Hub for their cultural adventures
          </p>
          
          <Button 
            size="lg"
            onClick={() => setIsChatOpen(true)}
            className="bg-background text-primary hover:bg-background/90 text-lg px-8 py-6 shadow-xl hover:shadow-2xl transition-all duration-300"
          >
            Start Your Heritage Journey <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted/50 py-12 border-t border-border/50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Building className="h-6 w-6 text-primary" />
                <span className="text-xl font-bold">Indian Museum Hub</span>
              </div>
              <p className="text-muted-foreground">
                Your gateway to India's most incredible museums and cultural heritage experiences.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <div className="space-y-2 text-muted-foreground">
                <a href="#" className="block hover:text-primary transition-colors">About Us</a>
                <a href="#" className="block hover:text-primary transition-colors">Contact</a>
                <a href="#" className="block hover:text-primary transition-colors">Help Center</a>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <div className="space-y-2 text-muted-foreground">
                <a href="#" className="block hover:text-primary transition-colors">Museum Tickets</a>
                <a href="#" className="block hover:text-primary transition-colors">Heritage Tours</a>
                <a href="#" className="block hover:text-primary transition-colors">Group Bookings</a>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <div className="space-y-2 text-muted-foreground">
                <a href="#" className="block hover:text-primary transition-colors">Privacy Policy</a>
                <a href="#" className="block hover:text-primary transition-colors">Terms of Service</a>
                <a href="#" className="block hover:text-primary transition-colors">Cookie Policy</a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-border/50 mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2024 Indian Museum Hub. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Chat Widget */}
      <ChatWidget isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />
    </div>
  );
};

export default Index;
