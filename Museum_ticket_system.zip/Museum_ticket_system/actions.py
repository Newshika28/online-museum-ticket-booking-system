from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher

class ActionHandleBooking(Action):
    def name(self) -> Text:
        return "action_handle_booking"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        number = tracker.get_slot("number")
        date = tracker.get_slot("date")
        show_name = tracker.get_slot("show_name")

        if number and date and show_name:
            dispatcher.utter_message(
                text=f"✅ Your {number} ticket(s) for '{show_name}' on {date} has been booked! Enjoy the show!"
            )
        else:
            dispatcher.utter_message(
                text="❗I need the number of tickets, date, and show name to book your tickets. Can you provide them?"
            )

        return []
